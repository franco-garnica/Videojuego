/*
CLASE MENU
Dibuja la pantalla inicial y permite elegir el equipo.

skinElegida es una variable global:
0 = Eje
1 = Aliados

mostrar() dibuja el fondo, las opciones de tanque y el botón JUGAR.
comprobarBoton() revisa dónde hizo clic el usuario y actualiza la elección
o cambia estadoJuego para comenzar la partida.
*/


class Menu {

  PImage fondo;
  PImage tanqueEje;
  PImage torretaEje;
  PImage tanqueAliados;
  PImage torretaAliados;

  // Posición y tamaño del botón
  float botonX = 600;
  float botonY = 690;
  float botonAncho = 250;
  float botonAlto = 75;

  // Constructor
  Menu() {
    fondo = loadImage("Fondo.png");

    tanqueEje = loadImage("TanqueEje.png");
    torretaEje = loadImage("TorretaEje.png");
    tanqueAliados = loadImage("TanqueAliados.png");
    torretaAliados = loadImage("TorretaAliados.png");
  }

  // Dibuja el menú y resalta la opción de equipo que está seleccionada.
  void mostrar() {

    imageMode(CORNER);
    image(fondo, 0, 0, width, height);

    textAlign(CENTER);
    fill(255);
    textSize(35);
    text("ELEGÍ TU TANQUE", width/2, 180);

    // Opción Eje
    if (skinElegida == 0) {
      stroke(255, 220, 0);
      strokeWeight(5);
    } else {
      noStroke();
    }

    fill(60);
    rect(width/2 - 220, 250, 180, 220);

    imageMode(CENTER);
    image(tanqueEje, width/2 - 130, 340, 130, 130);
    
    image(torretaEje, width/2 - 130, 327, 110, 110);

    fill(255);
    textSize(24);
    text("EJE", width/2 - 130, 440);

    // Opción Aliados
    if (skinElegida == 1) {
      stroke(255, 220, 0);
      strokeWeight(5);
    } else {
      noStroke();
    }

    fill(60);
    rect(width/2 + 40, 250, 180, 220);

    image(tanqueAliados, width/2 + 130, 340, 130, 130);
    
     image(torretaAliados, width/2 + 130, 327, 110, 110);

    fill(255);
    text("ALIADOS", width/2 + 130, 440);

    // Botón jugar
    imageMode(CORNER);
    noStroke();

    if (mouseX > botonX && mouseX < botonX + botonAncho &&
        mouseY > botonY && mouseY < botonY + botonAlto) {
      fill(80, 180, 80);
    } else {
      fill(40, 130, 40);
    }

    rect(botonX, botonY, botonAncho, botonAlto);

    fill(255);
    textSize(30);
    text("JUGAR", botonX + botonAncho/2,
         botonY + botonAlto/2 + 10);
  }

  // Comprueba las coordenadas del clic para elegir equipo o iniciar el juego.
  void comprobarBoton() {

    // Seleccionar Eje
    if (mouseX > width/2 - 220 &&
        mouseX < width/2 - 40 &&
        mouseY > 250 && mouseY < 470) {

      skinElegida = 0;
    }

    // Seleccionar Aliados
    else if (mouseX > width/2 + 40 &&
             mouseX < width/2 + 220 &&
             mouseY > 250 && mouseY < 470) {

      skinElegida = 1;
    }

    // Iniciar partida
    else if (mouseX > botonX &&
             mouseX < botonX + botonAncho &&
             mouseY > botonY &&
             mouseY < botonY + botonAlto) {

      estadoJuego = 1;
    }
  }
}
