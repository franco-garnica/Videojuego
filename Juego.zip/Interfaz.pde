/*
CLASE INTERFAZ
Muestra en pantalla las vidas restantes de los dos participantes.

Usa la misma imagen para representar cada vida:
- las del jugador aparecen a la izquierda;
- las del bot aparecen a la derecha.

Los bucles for dibujan una imagen por cada vida que todavía queda.
*/

class Interfaz {

  PImage imagenVida;

  // Constructor: carga la imagen que se usa para representar una vida.
  Interfaz() {
    // Cargar imagen que representa una vida.
    imagenVida = loadImage("Engranaje.png");
  }

  // Dibuja tantas vidas como tenga el tanque del jugador.
  void mostrarVidas(Tanque1 tanque) {

    imageMode(CENTER);

    // Dibujar una imagen por cada vida del jugador.
    for (int i = 0; i < tanque.vidas; i++) {

      float x = 35 + (i * 60);
      float y = 40;

      image(imagenVida, x, y, 80, 80);
    }

    fill(255);
    textAlign(LEFT);
    textSize(18);
    text("JUGADOR", 25, 95);
  }

  // Dibuja las vidas del bot en el lado derecho de la pantalla.
  void mostrarVidasBot(Bot bot) {

    imageMode(CENTER);

    // Dibujar las vidas del bot desde el lado derecho.
    for (int i = 0; i < bot.vidas; i++) {

      float x = width - 35 - (i * 60);
      float y = 40;

      image(imagenVida, x, y, 80, 80);
    }

    fill(255);
    textAlign(RIGHT);
    textSize(18);
    text("BOT", width - 25, 95);
  }
}
