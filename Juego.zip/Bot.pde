class Bot {

PImage imagenBot;
PImage imagenTorreta;
PImage imagenFuego;

// Variables del efecto visual del disparo.
boolean efectoActivo = false;
int tiempoDisparo;
int duracionEfecto = 100;

float x;
float y;

float velocidad = 2;
float ancho = 30;
float alto = 30;

float angulo = 0;
float anguloTorreta = 0;

float distanciaGiroTorreta = 5;
int vidas = 3;

int tiempoEntreDisparos = 1500;
int ultimoDisparo = -1500;

// Próximo casillero al que debe dirigirse el bot.
float destinoX;
float destinoY;

// Indica si el bot tiene un destino calculado.
boolean tieneDestino = false;

Bot(float xInicial, float yInicial, int skin) {
  x = xInicial;
  y = yInicial;

  if (skin == 0) {
    imagenBot = loadImage("TanqueAliados.png");
  } else {
    imagenBot = loadImage("TanqueEje.png");
  }

  imagenBot.resize(75, 75);

  if (skin == 0) {
    imagenTorreta = loadImage("TorretaAliados.png");
  } else {
    imagenTorreta = loadImage("TorretaEje.png");
  }

  imagenTorreta.resize(60, 60);

  // Imagen de fuego que aparece al disparar.
  imagenFuego = loadImage("Fuego.png");
  imagenFuego.resize(45, 45);

  destinoX = x;
  destinoY = y;
}

void mover(Tanque1 jugador) {
  if (vidas <= 0) return;

  // Si todavía no tiene un destino, busca el primero.
  if (!tieneDestino) {
    buscarCamino(jugador);
  }

  // Calcular la distancia hasta el centro del casillero.
  float diferenciaX = destinoX - x;
  float diferenciaY = destinoY - y;

  // Comprobar si llegó al destino.
  if (abs(diferenciaX) <= velocidad &&
      abs(diferenciaY) <= velocidad) {

    x = destinoX;
    y = destinoY;

    // Al llegar, buscar el siguiente casillero.
    tieneDestino = false;
    buscarCamino(jugador);

    diferenciaX = destinoX - x;
    diferenciaY = destinoY - y;
  }

  float nuevoX = x;
  float nuevoY = y;

  // Avanzar solamente en horizontal o vertical.
  if (abs(diferenciaX) > 1) {

    if (diferenciaX > 0) {
      nuevoX += velocidad;
    } else {
      nuevoX -= velocidad;
    }

    nuevoX = constrain(nuevoX, ancho/2, width - ancho/2);

    if (!mapa.colisiona(nuevoX, y, ancho, alto)) {
      x = nuevoX;
    } else {
      // Si encuentra una pared, buscar otro recorrido.
      tieneDestino = false;
    }

  } else if (abs(diferenciaY) > 1) {

    if (diferenciaY > 0) {
      nuevoY += velocidad;
    } else {
      nuevoY -= velocidad;
    }

    nuevoY = constrain(nuevoY, alto/2, height - alto/2);

    if (!mapa.colisiona(x, nuevoY, ancho, alto)) {
      y = nuevoY;
    } else {
      tieneDestino = false;
    }
  }

  // Girar el cuerpo según la dirección de movimiento.
  if (abs(diferenciaX) > 1) {
    if (diferenciaX > 0) angulo = HALF_PI;
    else angulo = -HALF_PI;
  } else if (abs(diferenciaY) > 1) {
    if (diferenciaY > 0) angulo = PI;
    else angulo = 0;
  }

  // Calcular distancia al jugador expresada en casilleros.
  float distanciaX = (jugador.x - x) / mapa.escalaX;
  float distanciaY = (jugador.y - y) / mapa.escalaY;
  float distancia = sqrt(distanciaX * distanciaX + distanciaY * distanciaY);

  // La torreta apunta y dispara si el jugador está cerca y visible.
  if (distancia <= distanciaGiroTorreta && caminoLibre(jugador)) {
    anguloTorreta = atan2(jugador.y - y, jugador.x - x) + HALF_PI;
    disparar(jugador);
  }
}

// Busca un camino desde el bot hasta el jugador.
void buscarCamino(Tanque1 jugador) {

  int inicioColumna = constrain(int(x / mapa.escalaX), 0, 15);
  int inicioFila = constrain(int(y / mapa.escalaY), 0, 15);

  int finalColumna = constrain(int(jugador.x / mapa.escalaX), 0, 15);
  int finalFila = constrain(int(jugador.y / mapa.escalaY), 0, 15);

  int inicio = inicioFila * 16 + inicioColumna;
  int objetivo = finalFila * 16 + finalColumna;

  // Si ya comparte casillero con el jugador, no necesita avanzar.
  if (inicio == objetivo) {
    destinoX = x;
    destinoY = y;
    tieneDestino = true;
    return;
  }

  boolean[] visitado = new boolean[256];
  int[] anterior = new int[256];
  int[] cola = new int[256];

  for (int i = 0; i < 256; i++) {
    anterior[i] = -1;
  }

  int primero = 0;
  int ultimo = 0;

  cola[ultimo] = inicio;
  ultimo++;
  visitado[inicio] = true;

  // Direcciones: derecha, izquierda, abajo y arriba.
  int[] cambioColumna = {1, -1, 0, 0};
  int[] cambioFila = {0, 0, 1, -1};

  // BFS: revisa primero los casilleros más cercanos.
  while (primero < ultimo && !visitado[objetivo]) {

    int actual = cola[primero];
    primero++;

    int columna = actual % 16;
    int fila = actual / 16;

    for (int i = 0; i < 4; i++) {

      int nuevaColumna = columna + cambioColumna[i];
      int nuevaFila = fila + cambioFila[i];

      if (nuevaColumna >= 0 && nuevaColumna < 16 &&
          nuevaFila >= 0 && nuevaFila < 16 &&
          mapa.casilleroLibre(nuevaColumna, nuevaFila, ancho, alto)) {

        int siguiente = nuevaFila * 16 + nuevaColumna;

        if (!visitado[siguiente]) {
          visitado[siguiente] = true;
          anterior[siguiente] = actual;
          cola[ultimo] = siguiente;
          ultimo++;
        }
      }
    }
  }

  // Si no encontró recorrido, espera y vuelve a intentar.
  if (!visitado[objetivo]) {
    destinoX = x;
    destinoY = y;
    tieneDestino = false;
    return;
  }

  // Retroceder desde el objetivo hasta encontrar el primer paso.
  int paso = objetivo;

  while (anterior[paso] != inicio && anterior[paso] != -1) {
    paso = anterior[paso];
  }

  int columnaPaso = paso % 16;
  int filaPaso = paso / 16;

  // Calcular el centro del siguiente casillero.
  destinoX = (columnaPaso + 0.5) * mapa.escalaX;
  destinoY = (filaPaso + 0.5) * mapa.escalaY;

  tieneDestino = true;
}

// Comprueba que no haya paredes entre el bot y el jugador.
boolean caminoLibre(Tanque1 jugador) {
  int pasos = int(dist(x, y, jugador.x, jugador.y) / 10);

  if (pasos < 1) return true;

  for (int i = 1; i < pasos; i++) {
    float porcentaje = i / float(pasos);

    float puntoX = x + (jugador.x - x) * porcentaje;
    float puntoY = y + (jugador.y - y) * porcentaje;

    if (mapa.colisiona(puntoX, puntoY, 4, 4)) {
      return false;
    }
  }

  return true;
}

void disparar(Tanque1 jugador) {
  if (millis() - ultimoDisparo >= tiempoEntreDisparos) {

    float anguloDisparo = atan2(jugador.y - y, jugador.x - x);

    proyectiles.add(new Proyectil(x, y, anguloDisparo, true));

    // Activar el efecto visual del disparo.
    efectoActivo = true;
    tiempoDisparo = millis();

    ultimoDisparo = millis();
  }
}

void mostrar() {
  if (vidas <= 0) return;

  imageMode(CENTER);

  // Mostrar el cuerpo del tanque.
  pushMatrix();
  translate(x, y);
  rotate(angulo);
  image(imagenBot, 0, 0);
  popMatrix();

  // Mostrar la torreta.
  pushMatrix();
  translate(x, y);
  rotate(anguloTorreta);
  image(imagenTorreta, 0, -13);
  popMatrix();

  // Mostrar el fuego por encima de la punta del cañón.
  mostrarEfecto();
}

void mostrarEfecto() {

  if (efectoActivo) {

    if (millis() - tiempoDisparo < duracionEfecto) {

      pushMatrix();
      translate(x, y);
      rotate(anguloTorreta);

      imageMode(CENTER);
      image(imagenFuego, 0, -55);

      popMatrix();

    } else {
      efectoActivo = false;
    }
  }
}

}
