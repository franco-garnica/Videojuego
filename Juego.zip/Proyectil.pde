/*
CLASE PROYECTIL
Representa una bala que se mueve en línea recta y rebota contra
las paredes del mapa.

pos guarda la posición y vel guarda la velocidad en X e Y.
disparoBot permite distinguir quién disparó:
true = lo disparó el bot
false = lo disparó el jugador

impacto() compara la posición de la bala con el rectángulo del tanque.
mostrar() dibuja la imagen de la bala con la orientación de su movimiento.
*/

class Proyectil {

  PVector pos;
  PVector vel;
  PImage imagenBala;

  // Indica si el disparo pertenece al bot.
  boolean disparoBot;

  // Constructor: crea la bala, calcula su dirección y guarda quién la disparó.
  Proyectil(float x, float y, float angulo, boolean esDelBot) {

    pos = new PVector(x, y);
    vel = new PVector(cos(angulo), sin(angulo));
    vel.mult(8);

    disparoBot = esDelBot;

    imagenBala = loadImage("Bala.png");
    imagenBala.resize(40, 40);

  }

  // Avanza la bala y cambia el sentido de la velocidad si encuentra una pared.
  void mover() {

    pos.add(vel);

    // Rebotar contra las paredes del mapa.
    if (mapa.colisiona(pos.x + vel.x, pos.y, 8, 8)) {
      vel.x *= -1;
    }

    if (mapa.colisiona(pos.x, pos.y + vel.y, 8, 8)) {
      vel.y *= -1;
    }
  }

  // Comprobar si el proyectil toca un tanque.
  // Devuelve true si la posición de la bala está dentro del área del tanque.
  boolean impacto(float xTanque, float yTanque,
                  float anchoTanque, float altoTanque) {

    if (abs(pos.x - xTanque) < anchoTanque / 2 &&
        abs(pos.y - yTanque) < altoTanque / 2) {
      return true;
    }

    return false;
  }

  // Dibuja la bala girada según la dirección en la que se mueve.
  void mostrar() {

    imageMode(CENTER);

    pushMatrix();
    translate(pos.x, pos.y);
    rotate(atan2(vel.y, vel.x));
    image(imagenBala, 0, 0);
    popMatrix();
  }
}
