int estadoJuego = 0;
int skinElegida = 0;

int numeroMapa = 1;
int totalMapas = 5;

Menu menu;
Mapa mapa;
Tanque1 tanque1;
Torreta torreta;
Bot bot;
Interfaz interfaz;
Partida partida;

ArrayList<Proyectil> proyectiles = new ArrayList<Proyectil>();

int tiempoEntreDisparos = 1500;
int ultimoDisparo = -1500;

void setup() {
  fullScreen(P2D);

  menu = new Menu();
  mapa = new Mapa();
  interfaz = new Interfaz();
  partida = new Partida();
}

void draw() {

  if (estadoJuego == 0) {
    menu.mostrar();
  }

  else if (estadoJuego == 1) {
    background(0);

    imageMode(CORNER);
    mapa.mostrar();

    tanque1.mover();
    bot.mover(tanque1);
    torreta.mover();

    tanque1.mostrar();
    bot.mostrar();
    torreta.mostrar();

    // Mover proyectiles y comprobar a quién golpean.
    for (int i = proyectiles.size() - 1; i >= 0; i--) {
      Proyectil p = proyectiles.get(i);
      p.mover();

      if (p.disparoBot) {
        if (tanque1.vidas > 0 &&
            p.impacto(tanque1.x, tanque1.y, tanque1.ancho, tanque1.alto)) {
          tanque1.vidas--;
          proyectiles.remove(i);
        } else {
          p.mostrar();
        }
      } else {
        if (bot.vidas > 0 &&
            p.impacto(bot.x, bot.y, bot.ancho, bot.alto)) {
          bot.vidas--;
          proyectiles.remove(i);
        } else {
          p.mostrar();
        }
      }
    }

    interfaz.mostrarVidas(tanque1);
    interfaz.mostrarVidasBot(bot);

    // Si el jugador pierde, termina la ronda y podrá reintentarla.
    partida.comprobarResultado(tanque1);

    if (partida.terminada) {
      estadoJuego = 2;
    }

    // Si el bot pierde, se avanza al mapa siguiente.
    else if (bot.vidas <= 0) {
      if (numeroMapa < totalMapas) {
        numeroMapa++;
        iniciarSiguienteMapa();
      } else {
        partida.campaniaCompletada = true;
        partida.terminada = true;
        estadoJuego = 2;
      }
    }
  }

  else if (estadoJuego == 2) {
    partida.mostrar(numeroMapa, totalMapas);
  }
}

void mousePressed() {

  if (estadoJuego == 0) {
    menu.comprobarBoton();

    if (estadoJuego == 1) {
      numeroMapa = 1;
      iniciarJuegoNuevo();
    }
  }

  else if (estadoJuego == 1 && mouseButton == LEFT) {
    if (millis() - ultimoDisparo >= tiempoEntreDisparos) {

      float angulo = atan2(
        mouseY - tanque1.y,
        mouseX - tanque1.x
      );

      proyectiles.add(
        new Proyectil(tanque1.x, tanque1.y, angulo, false)
      );
      
      torreta.activarEfecto();

      ultimoDisparo = millis();
    }
  }
}

void keyPressed() {

  if (key == 'r' || key == 'R') {

    // Si se completó la campaña, R vuelve al primer mapa.
    if (partida.campaniaCompletada) {
      numeroMapa = 1;
      iniciarJuegoNuevo();
    }

    // Si perdió, reintenta el mapa actual desde el principio.
    else if (estadoJuego == 2) {
      reintentarMapa();
    }
  }
}

// Comienza una campaña nueva desde el mapa 1.
void iniciarJuegoNuevo() {
  tanque1 = new Tanque1(width * 0.16, height * 0.84, skinElegida);
  tanque1.vidas = 3;

  mapa.cambiarMapa(numeroMapa);
  crearBot();

  torreta = new Torreta(tanque1, skinElegida);
  torreta.tanque = tanque1;

  proyectiles.clear();
  ultimoDisparo = -1500;

  partida.iniciar();
  estadoJuego = 1;
}

// Al pasar de mapa, el jugador conserva las vidas que le quedaron.
void iniciarSiguienteMapa() {
  int vidasRestantes = tanque1.vidas;

  mapa.cambiarMapa(numeroMapa);

  tanque1 = new Tanque1(width * 0.16, height * 0.84, skinElegida);
  tanque1.vidas = vidasRestantes;

  crearBot();

  torreta = new Torreta(tanque1, skinElegida);
  torreta.tanque = tanque1;

  proyectiles.clear();
  ultimoDisparo = -1500;
}

// Al perder, se reinicia el mapa actual con tres vidas.
void reintentarMapa() {
  tanque1 = new Tanque1(width * 0.16, height * 0.84, skinElegida);
  tanque1.vidas = 3;

  mapa.cambiarMapa(numeroMapa);
  crearBot();

  torreta = new Torreta(tanque1, skinElegida);
  torreta.tanque = tanque1;

  proyectiles.clear();
  ultimoDisparo = -1500;

  partida.iniciar();
  estadoJuego = 1;
}

// Crea al bot en la zona opuesta al jugador.
void crearBot() {
  bot = new Bot(width * 0.90, height * 0.10, skinElegida);
}
