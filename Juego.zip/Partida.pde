class Partida {

  String resultado = "";
  boolean terminada = false;
  boolean campaniaCompletada = false
  
  
  ;

  void iniciar() {
    resultado = "";
    terminada = false;
    campaniaCompletada = false;
  }

  // Comprueba si el jugador perdió la ronda.
  void comprobarResultado(Tanque1 jugador) {
    if (jugador.vidas <= 0) {
      resultado = "DERROTA";
      terminada = true;
    }
  }

  void mostrar(int numeroMapa, int totalMapas) {
    background(20);
    textAlign(CENTER, CENTER);
    fill(255);
    textSize(60);

    if (campaniaCompletada) {
      text("¡CAMPAÑA COMPLETADA!", width / 2, height / 2 - 40);
      textSize(25);
      text("¡Ganaste los " + totalMapas + " mapas!", width / 2, height / 2 + 25);
      text("Presioná R para volver a empezar", width / 2, height / 2 + 75);
    } else {
      text(resultado, width / 2, height / 2 - 50);
      textSize(25);
      text("Mapa " + numeroMapa + " de " + totalMapas, width / 2, height / 2 + 5);
      text("Presioná R para reintentar este mapa", width / 2, height / 2 + 55);
    }
  }
}
