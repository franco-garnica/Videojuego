/*
CLASE MAPAS
Guarda las cinco distribuciones posibles del escenario.

Cada pared se representa con cuatro valores:
{columna, fila, cantidad de columnas, cantidad de filas}

La cuadrícula tiene 16 columnas y 16 filas, igual que el mapa original.
Esta clase solamente entrega los datos: no dibuja ni comprueba colisiones.
*/

class Mapas {

  float[][] obtenerMapa(int numero) {

    // MAPA 1: distribución original del proyecto.
    if (numero == 1) {
      return new float[][] {
        {1, 1, 1, 6}, {4, 1, 1, 6}, {7, 1, 1, 4},
        {10, 1, 1, 4}, {13, 1, 1, 6}, {7, 6, 1, 1},
        {10, 6, 1, 1}, {1, 8, 4, 1}, {7, 8, 4, 3},
        {12, 8, 3, 1}, {1, 10, 1, 5}, {4, 10, 1, 4},
        {13, 10, 1, 5}, {7, 12, 4, 3}
      };
    }

    // MAPA 2: pasillos verticales y obstáculos centrales.
    else if (numero == 2) {
      return new float[][] {
        {3, 1, 1, 5}, {6, 3, 1, 6}, {9, 1, 1, 5},
        {12, 3, 1, 6}, {1, 5, 2, 1}, {4, 8, 3, 1},
        {9, 8, 3, 1}, {13, 10, 2, 1}, {2, 11, 3, 1},
        {6, 12, 1, 3}, {10, 12, 1, 3}
      };
    }

    // MAPA 3: varios bloques que obligan a rodear obstáculos.
    else if (numero == 3) {
      return new float[][] {
        {2, 2, 3, 1}, {7, 1, 1, 4}, {11, 2, 3, 1},
        {1, 5, 1, 4}, {4, 5, 4, 1}, {10, 5, 1, 4},
        {13, 5, 2, 1}, {3, 8, 3, 1}, {7, 8, 1, 4},
        {11, 8, 3, 1}, {2, 12, 3, 1}, {10, 12, 3, 1}
      };
    }

    // MAPA 4: sectores conectados por corredores.
    else if (numero == 4) {
      return new float[][] {
        {3, 1, 1, 7}, {7, 1, 1, 5}, {11, 1, 1, 7},
        {1, 4, 2, 1}, {4, 4, 3, 1}, {8, 4, 3, 1},
        {12, 4, 3, 1}, {1, 9, 3, 1}, {5, 8, 1, 5},
        {8, 9, 3, 1}, {12, 9, 3, 1}, {3, 13, 1, 2},
        {9, 13, 1, 2}
      };
    }

    // MAPA 5: distribución final con obstáculos en zigzag.
    else {
      return new float[][] {
        {2, 1, 4, 1}, {8, 1, 4, 1}, {13, 2, 1, 4},
        {1, 4, 1, 4}, {4, 4, 4, 1}, {9, 4, 3, 1},
        {3, 7, 1, 4}, {6, 7, 4, 1}, {11, 7, 1, 4},
        {13, 9, 2, 1}, {1, 12, 4, 1}, {6, 12, 1, 3},
        {9, 12, 4, 1}
      };
    }
  }
}
