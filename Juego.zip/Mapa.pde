class Mapa {

  PImage[] fondos = new PImage[5];
  PImage[] imagenesParedes = new PImage[5];

  float escalaX, escalaY;

  // Clase que contiene las cinco distribuciones.
  Mapas mapas;
  float[][] paredes;

  // Número del mapa que se está utilizando.
  int numeroMapa = 1;

  Mapa() {
    escalaX = width / 16.0;
    escalaY = height / 16.0;

    // Cargar los cinco fondos.
    fondos[0] = loadImage("Desierto.png");
    fondos[1] = loadImage("Pueblo.png");
    fondos[2] = loadImage("Nieve.png");
    fondos[3] = loadImage("Bosque.png");
    fondos[4] = loadImage("Urbano.png");

    // Cargar las cinco texturas de paredes.
    imagenesParedes[0] = loadImage("ParedDesierto.png");
    imagenesParedes[1] = loadImage("ParedPueblo.png");
    imagenesParedes[2] = loadImage("ParedNieve.png");
    imagenesParedes[3] = loadImage("ParedBosque.png");
    imagenesParedes[4] = loadImage("ParedUrbano.png");

    // Ajustar el tamaño de las imágenes de pared.
    for (int i = 0; i < imagenesParedes.length; i++) {
      imagenesParedes[i].resize((int)escalaX, (int)escalaY);
    }

    mapas = new Mapas();
    cambiarMapa(1);
  }

  // Carga la distribución correspondiente al mapa.
  void cambiarMapa(int numero) {
    numeroMapa = constrain(numero, 1, 5);
    paredes = mapas.obtenerMapa(numeroMapa);
  }

  // Dibuja el fondo y las paredes del mapa actual.
  void mostrar() {

    imageMode(CORNER);

    // Seleccionar las imágenes correspondientes.
    image(fondos[numeroMapa - 1], 0, 0, width, height);

    PImage paredActual = imagenesParedes[numeroMapa - 1];

    // Dibujar las paredes.
    for (int i = 0; i < paredes.length; i++) {

      float x = paredes[i][0] * escalaX;
      float y = paredes[i][1] * escalaY;
      float ancho = paredes[i][2] * escalaX;
      float alto = paredes[i][3] * escalaY;

      for (float px = x; px < x + ancho; px += escalaX) {
        for (float py = y; py < y + alto; py += escalaY) {

          image(paredActual, px, py, escalaX, escalaY);

        }
      }
    }
  }

  // Comprueba si un tanque o proyectil choca con alguna pared.
  boolean colisiona(float x, float y, float ancho, float alto) {

    float margen = 3;

    for (int i = 0; i < paredes.length; i++) {

      float px = paredes[i][0] * escalaX;
      float py = paredes[i][1] * escalaY;
      float pw = paredes[i][2] * escalaX;
      float ph = paredes[i][3] * escalaY;

      if (x + ancho/2 + margen > px &&
          x - ancho/2 - margen < px + pw &&
          y + alto/2 + margen > py &&
          y - alto/2 - margen < py + ph) {

        return true;
      }
    }

    return false;
  }

  // Comprueba si un casillero está libre para el BFS.
  boolean casilleroLibre(int columna, int fila, float ancho, float alto) {

    if (columna < 0 || columna >= 16 ||
        fila < 0 || fila >= 16) {
      return false;
    }

    float centroX = (columna + 0.5) * escalaX;
    float centroY = (fila + 0.5) * escalaY;

    return !colisiona(centroX, centroY, ancho, alto);
  }
}
