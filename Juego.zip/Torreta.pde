/*
CLASE TORRETA
Representa la torreta del tanque del jugador.

La variable tanque guarda una referencia al tanque al que pertenece.
mover() calcula el ángulo entre el tanque y el cursor del mouse.
mostrar() dibuja la torreta sobre la posición del tanque.

La torreta no mueve el cuerpo del tanque: solamente cambia hacia dónde apunta.
*/

class Torreta {

  PImage imagenTorreta;
  PImage imagenFuego;

  Tanque1 tanque;
  float angulo;

  boolean efectoActivo = false;
  int tiempoDisparo;
  int duracionEfecto = 180;

  // Constructor
  Torreta(Tanque1 tanque, int skin) {

    this.tanque = tanque;

    // Cargar la torreta según la facción elegida.
    if (skin == 0) {
      imagenTorreta = loadImage("TorretaEje.png");
    } else {
      imagenTorreta = loadImage("TorretaAliados.png");
    }

    imagenTorreta.resize(60, 60);

    // Cargar imagen del fuego.
    imagenFuego = loadImage("Fuego.png");
    imagenFuego.resize(45, 45);
  }

  void mover() {
    angulo = atan2(mouseY - tanque.y, mouseX - tanque.x) + HALF_PI;
  }

  void mostrar() {

    imageMode(CENTER);

    pushMatrix();

    translate(tanque.x, tanque.y);
    rotate(angulo);

    image(imagenTorreta, 0, -13);

    popMatrix();

    mostrarEfecto();
  }

  // Activa el efecto cuando dispara el jugador.
  void activarEfecto() {
    efectoActivo = true;
    tiempoDisparo = millis();
  }

  // Muestra el fuego durante un instante.
  void mostrarEfecto() {

    if (efectoActivo) {

      if (millis() - tiempoDisparo < duracionEfecto) {

        pushMatrix();

        translate(tanque.x, tanque.y);
        rotate(angulo);

        imageMode(CENTER);
        image(imagenFuego, 0, -55);

        popMatrix();

      } else {
        efectoActivo = false;
      }
    }
  }
}
