/*
CLASE TANQUE1
Representa al tanque que controla el jugador.

- Guarda su posición, velocidad, tamaño, ángulo e imágenes.
- El constructor recibe la posición inicial y la skin elegida.
- mover() lee WASD, calcula una nueva posición y consulta al Mapa
  antes de aceptar el movimiento.
- mostrar() dibuja el tanque girado hacia la dirección de movimiento.

IMPORTANTE:
mapa es una variable global del archivo principal. Por eso esta clase
puede llamar a mapa.colisiona(...) sin crear otro mapa.
*/



class Tanque1 {

  PImage imagenTanque1;

  float x;
  float y;
  float velocidad = 4;

  // Tamaño de la zona de colision.
  float ancho = 30;
  float alto = 30;

  float angulo = 0;

  int vidas = 3;

  // Constructor
  Tanque1(float xInicial, float yInicial, int skin) {

    x = xInicial;
    y = yInicial;

    if (skin == 0) {
      imagenTanque1 = loadImage("TanqueEje.png");
    } else {
      imagenTanque1 = loadImage("TanqueAliados.png");
    }

    // Reducir el tamaño visual del tanque.
    imagenTanque1.resize(75, 75);
  }

  void mover() {

    float movimientoX = 0;
    float movimientoY = 0;

    if (keyPressed) {
      if (key == 'a' || key == 'A') movimientoX -= 1;
      if (key == 'd' || key == 'D') movimientoX += 1;
      if (key == 'w' || key == 'W') movimientoY -= 1;
      if (key == 's' || key == 'S') movimientoY += 1;
    }

    float nuevoX = x + movimientoX * velocidad;
    float nuevoY = y + movimientoY * velocidad;

    // Girar según la dirección.
    if (movimientoX != 0 || movimientoY != 0) {
      angulo = atan2(movimientoX, movimientoY);
    }

    // Evitar salir de la pantalla.
    nuevoX = constrain(nuevoX, ancho / 2, width - ancho / 2);
    nuevoY = constrain(nuevoY, alto / 2, height - alto / 2);

    // Comprobar colisiones.
    if (!mapa.colisiona(nuevoX, y, ancho, alto)) {
      x = nuevoX;
    }

    if (!mapa.colisiona(x, nuevoY, ancho, alto)) {
      y = nuevoY;
    }
  }

  void mostrar() {

    imageMode(CENTER);

    pushMatrix();

    translate(x, y);
    rotate(angulo);

    image(imagenTanque1, 0, 0);

    popMatrix();
  }
}
